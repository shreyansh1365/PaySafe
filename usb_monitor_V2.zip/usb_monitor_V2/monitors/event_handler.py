class EventHandler:

    def process_event(self, action, filename):

        print("=" * 50)
        print("EVENT RECEIVED")
        print(f"Action   : {action}")
        print(f"File     : {filename}")
        print("=" * 50)