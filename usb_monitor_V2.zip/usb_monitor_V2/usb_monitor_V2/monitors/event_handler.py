from datetime import datetime
import os


from database.usb_logs import insert_usb_log
from database.transfer_logs import insert_transfer_log
from hashing.sha256 import calculate_sha256


class EventHandler:

    def __init__(self, info):

        self.info = info

    def process_event(self, action, filename, full_path):

        print("=" * 50)
        print("EVENT RECEIVED")
        print(f"Action   : {action}")
        print(f"File     : {filename}")
        print("=" * 50)

        insert_usb_log(
            datetime.now(),
            self.info["username"],
            self.info["system_name"],
            self.info["drive"],
            self.info["usb_name"],
            self.info["device_id"],
            action,
            self.info["device_code"],
            self.info["mac_address"],
            None
        )

        print("Event saved successfully.")
        # Only process files that still exist
        if not os.path.isfile(full_path):
            return
        
        file_size = round(os.path.getsize(full_path) / (1024 * 1024), 4)

        sha256 = calculate_sha256(full_path)
        insert_transfer_log(
            datetime.now(),
            self.info["username"],
            self.info["system_name"],
            self.info["device_code"],
            action,
            filename,
            file_size,
            sha256
        )

        print("Transfer log saved successfully.")