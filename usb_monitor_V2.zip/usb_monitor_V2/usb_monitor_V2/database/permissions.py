from database.db import get_connection


def is_device_trusted(device_code):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM trusted_devices
        WHERE device_code=%s
        """,
        (device_code,)
    )

    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result is not None


def is_device_blocked(device_code):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        SELECT *
        FROM blocked_devices
        WHERE device_code=%s
        """,
        (device_code,)
    )

    result = cursor.fetchone()

    cursor.close()
    conn.close()

    return result is not None


def approve_device(
    device_code,
    serial_number,
    device_name,
    admin
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO trusted_devices
        (
            device_code,
            serial_number,
            device_name,
            approved_by
        )
        VALUES
        (%s,%s,%s,%s)
        """,
        (
            device_code,
            serial_number,
            device_name,
            admin
        )
    )

    conn.commit()

    cursor.close()
    conn.close()


def block_device(
    device_code,
    serial_number,
    admin,
    reason
):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO blocked_devices
        (
            device_code,
            serial_number,
            blocked_by,
            reason
        )
        VALUES
        (%s,%s,%s,%s)
        """,
        (
            device_code,
            serial_number,
            admin,
            reason
        )
    )

    conn.commit()

    cursor.close()
    conn.close()

def check_permission(device_code):

 if is_device_blocked(device_code):
    return "BLOCKED"

 if is_device_trusted(device_code):
    return "ALLOWED"

 return "PENDING"