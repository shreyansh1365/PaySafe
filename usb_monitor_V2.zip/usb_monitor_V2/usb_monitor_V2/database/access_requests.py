from database.db import get_connection


def create_access_request(
    device_code,
    serial_number,
    device_name
):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        INSERT INTO usb_access_requests
        (
            device_code,
            serial_number,
            device_name,
            status
        )
        VALUES
        (%s,%s,%s,'PENDING')
        """,
        (
            device_code,
            serial_number,
            device_name
        )
    )

    conn.commit()

    cursor.close()
    conn.close()


def pending_requests():

    conn = get_connection()
    cursor = conn.cursor(dictionary=True)

    cursor.execute(
        """
        SELECT *
        FROM usb_access_requests
        WHERE status='PENDING'
        ORDER BY request_time DESC
        """
    )

    rows = cursor.fetchall()

    cursor.close()
    conn.close()

    return rows


def update_request_status(
    request_id,
    status
):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        """
        UPDATE usb_access_requests
        SET status=%s
        WHERE id=%s
        """,
        (
            status,
            request_id
        )
    )

    conn.commit()

    cursor.close()
    conn.close()