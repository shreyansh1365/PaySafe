print("THIS IS THE CORRECT MONITOR FILE")

import time

from usb.detector import get_connected_usb
from usb.device_info import get_device_info

from database.usb_logs import insert_usb_log

from monitors.directory_monitor import DirectoryMonitor

def main():

    print("=" * 60)
    print("USB Monitor Version 2 Started")
    print("=" * 60)

    previous = {}

    while True:

        print("Loop Running")

        current = get_connected_usb()

        if current != previous:

           if len(current) > len(previous):

              print("USB Connected")
              print(current)

           elif len(current) < len(previous):

                print("USB Removed")
                print(previous)

        previous = current

        time.sleep(2)

if __name__ == "__main__":
    main()