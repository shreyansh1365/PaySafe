@echo off
cd /d C:\USB_Sentinel\agent
python monitor.py